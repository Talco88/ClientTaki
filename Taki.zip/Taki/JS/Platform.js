﻿var platform = {};
